func salad() {
    print("Your base is \(bases.randomElement()!).")
    print("Your toppings are \(toppings.randomElement()!) and \(toppingsTwo.randomElement()!).")
    print("Finish off the salad with \(toppingsThree.randomElement()!) and \(cheese.randomElement()!).")
    print("Your dressing is \(dressing.randomElement()!).")
}
var bases = ["kale", "arugula", "iceberg lettuce", "lettuce", "spinach", "red lettuce", "romaine lettuce", "cabbage", "red cabbage"]
var toppings = ["broccoli", "cauliflower", "bell pepper", "roma tomatoes", "yellow tomatoes", "cherry tomatoes", "grape tomatoes", "avocado", "carrots", "celery", "chives", "onions", "red onions", "mushrooms", "corn", "watermelon"]
var toppingsTwo = ["olives", "beets", "zucchini", "black beans", "red beans", "kidney beans", "green beans", "lentils", "parsley", "dill", "eggplant", "cucumber", "pickles", "orange", "strawberries", "fig", "grapes", "apple", "cranberries", "hard boiled eggs"]
var toppingsThree = ["quinoa", "sesame seeds", "pumpkin seeds", "walnuts", "almonds", "pine nuts", "croutons", "oregano", "basil"]
var cheese = ["parmesan", "goat cheese", "blue cheese", "mozzarella", "asiago", "feta", "cheddar"]
var dressing = ["balsamic", "honey", "apple cider vinegar", "honey mustard", "yogurt", "caesar", "olive oil", "blue cheese", "red wine vinaigrette", "ranch"]

salad()
